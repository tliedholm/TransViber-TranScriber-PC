"""Merge per-track segments into a single chronological conversation."""

from __future__ import annotations

from models import Segment, Track


def merge_tracks(tracks: list[Track]) -> list[Segment]:
    """All segments from all tracks, ordered by start time."""
    segments = [seg for track in tracks for seg in track.segments]
    segments.sort(key=lambda s: (s.start, s.end))
    return segments


def coalesce(segments: list[Segment]) -> list[Segment]:
    """Join consecutive segments from the same speaker into one block.

    Used for readable (Markdown/plain text) output. SRT/VTT keep the
    original fine-grained segments for accurate subtitle timing.
    """
    blocks: list[Segment] = []
    for seg in segments:
        if blocks and blocks[-1].speaker == seg.speaker:
            prev = blocks[-1]
            prev.text = (prev.text.rstrip() + " " + seg.text.strip()).strip()
            prev.end = max(prev.end, seg.end)
        else:
            blocks.append(Segment(seg.speaker, seg.start, seg.end, seg.text.strip()))
    return blocks
