"""Background transcription worker using faster-whisper (CTranslate2)."""

from __future__ import annotations

import sys

import cuda_setup  # noqa: F401  (must run before ctranslate2 loads)

from PySide6.QtCore import QThread, Signal

from models import Segment, Track

# A pause this long between words splits a Whisper segment in two. Whisper can
# lump utterances separated by silence into one segment, which would sort a
# speaker's later remark at the time of their earlier one and break the
# conversation interleaving.
SPLIT_GAP_SECONDS = 1.0

# NVIDIA models (and other non-Whisper models) run through onnx-asr instead
# of faster-whisper. UI names map to onnx-asr model ids.
ONNX_ALIASES = {
    "parakeet-tdt-0.6b-v3": "nemo-parakeet-tdt-0.6b-v3",
    "parakeet-tdt-0.6b-v2": "nemo-parakeet-tdt-0.6b-v2",
    "parakeet": "nemo-parakeet-tdt-0.6b-v3",
    "canary-1b-v2": "nemo-canary-1b-v2",
    "canary": "nemo-canary-1b-v2",
}


def engine_for(model_name: str) -> str:
    n = model_name.lower()
    # Route anything Parakeet/Canary-shaped to onnx-asr, even misspellings of
    # the exact id — its "unknown model" error is clearer than faster-whisper
    # failing to find a Hugging Face repo of that name.
    if n in ONNX_ALIASES or n.startswith(
        ("nemo-", "parakeet", "canary", "gigaam", "alphacep/", "t-tech/")
    ):
        return "onnx"
    return "whisper"


# The model is loaded lazily and cached so repeated runs (and multiple
# tracks) reuse it. Only one model is kept to limit VRAM use.
_model_cache: dict = {"key": None, "model": None}


def split_on_word_gaps(fw_segment, speaker: str, max_gap: float = SPLIT_GAP_SECONDS) -> list[Segment]:
    """Split a faster-whisper segment at silence gaps between its words."""
    words = fw_segment.words
    if not words:
        return [Segment(speaker, fw_segment.start, fw_segment.end, fw_segment.text)]
    pieces: list[Segment] = []
    current = [words[0]]
    for word in words[1:]:
        if word.start - current[-1].end > max_gap:
            pieces.append(Segment(speaker, current[0].start, current[-1].end,
                                  "".join(w.word for w in current)))
            current = [word]
        else:
            current.append(word)
    pieces.append(Segment(speaker, current[0].start, current[-1].end,
                          "".join(w.word for w in current)))
    return pieces


def cuda_available() -> bool:
    import ctranslate2

    return ctranslate2.get_cuda_device_count() > 0


def mlx_available() -> bool:
    """mlx-whisper runs Whisper on Apple-silicon GPUs (macOS only)."""
    if sys.platform != "darwin":
        return False
    try:
        import mlx_whisper  # noqa: F401

        return True
    except ImportError:
        return False


# Whisper model name -> MLX conversion on Hugging Face, used when the device
# is Apple GPU ("mlx"). Unlisted names are passed through as repo ids.
MLX_REPOS = {
    "large-v3-turbo": "mlx-community/whisper-large-v3-turbo",
    "large-v3": "mlx-community/whisper-large-v3-mlx",
    "large-v2": "mlx-community/whisper-large-v2-mlx",
    "distil-large-v3": "mlx-community/distil-whisper-large-v3",
    "medium": "mlx-community/whisper-medium-mlx",
    "medium.en": "mlx-community/whisper-medium.en-mlx",
    "small": "mlx-community/whisper-small-mlx",
    "small.en": "mlx-community/whisper-small.en-mlx",
    "base": "mlx-community/whisper-base-mlx",
    "base.en": "mlx-community/whisper-base.en-mlx",
    "tiny": "mlx-community/whisper-tiny",
    "tiny.en": "mlx-community/whisper-tiny.en-mlx",
}


class _MlxModel:
    """Marker object standing in for a model handled by mlx_whisper.transcribe."""

    def __init__(self, repo: str):
        self.repo = repo


def _get_model(model_name: str, device: str, status_cb) -> object:
    engine = engine_for(model_name)
    key = (engine, model_name, device)
    if _model_cache["key"] != key:
        _model_cache["key"] = None
        _model_cache["model"] = None  # free previous model before loading a new one
        status_cb(f"Loading model '{model_name}' ({device}) — first use downloads it, "
                  "which can take several minutes for large models…")
        if engine == "onnx":
            import onnx_asr

            providers = {
                "cuda": ["CUDAExecutionProvider", "CPUExecutionProvider"],
                "mlx": ["CoreMLExecutionProvider", "CPUExecutionProvider"],
            }.get(device, ["CPUExecutionProvider"])
            onnx_name = ONNX_ALIASES.get(model_name.lower(), model_name)
            model = onnx_asr.load_model(onnx_name, providers=providers)
            _model_cache["model"] = model.with_vad(onnx_asr.load_vad("silero"))
        elif device == "mlx" and mlx_available():
            _model_cache["model"] = _MlxModel(MLX_REPOS.get(model_name, model_name))
        else:
            from faster_whisper import WhisperModel

            ct2_device = "cuda" if device == "cuda" else "cpu"
            compute_type = "float16" if ct2_device == "cuda" else "int8"
            _model_cache["model"] = WhisperModel(model_name, device=ct2_device,
                                                 compute_type=compute_type)
        _model_cache["key"] = key
    return _model_cache["model"]


class TranscribeWorker(QThread):
    model_status = Signal(str)
    track_started = Signal(int)
    segment_ready = Signal(int, object)  # (track index, Segment)
    track_progress = Signal(int, int)  # (track index, percent)
    track_done = Signal(int, str)  # (track index, detected language)
    track_failed = Signal(int, str)  # (track index, error message)
    finished_all = Signal(bool)  # cancelled?

    def __init__(self, tracks: list[Track], indices: list[int], model_name: str,
                 device: str, language: str | None, hotwords: str = "", parent=None):
        super().__init__(parent)
        self.tracks = tracks
        self.indices = indices
        self.model_name = model_name
        self.device = device
        self.language = language
        self.hotwords = hotwords.strip()
        self._stop = False

    def stop(self) -> None:
        self._stop = True

    def _load_model(self) -> object | None:
        """Load the model on the requested device, spilling over to CPU if the GPU fails."""
        try:
            return _get_model(self.model_name, self.device, self.model_status.emit)
        except Exception as exc:
            if self.device == "cpu":
                raise
            self.model_status.emit(f"GPU model load failed ({exc}) — falling back to CPU…")
            self.device = "cpu"
            return _get_model(self.model_name, self.device, self.model_status.emit)

    def _transcribe_track(self, model, i: int) -> bool:
        """Transcribe one track. Returns True if cancelled mid-track."""
        if engine_for(self.model_name) == "onnx":
            return self._transcribe_track_onnx(model, i)
        if isinstance(model, _MlxModel):
            return self._transcribe_track_mlx(model, i)
        track = self.tracks[i]
        self.track_started.emit(i)
        if track.is_subtrack:
            from audio import decode_track_audio

            source = decode_track_audio(track.path, track.stream_index, track.channel)
        else:
            source = str(track.path)
        segments, info = model.transcribe(
            source,
            language=self.language,
            beam_size=5,
            vad_filter=True,
            word_timestamps=True,
            condition_on_previous_text=False,
            hotwords=self.hotwords or None,
        )
        duration = info.duration or track.duration or 0.0
        for seg in segments:
            if self._stop:
                return True
            for piece in split_on_word_gaps(seg, track.speaker):
                self.segment_ready.emit(i, piece)
            if duration > 0:
                self.track_progress.emit(i, min(100, int(seg.end / duration * 100)))
        self.track_progress.emit(i, 100)
        self.track_done.emit(i, info.language or "")
        return False

    def _transcribe_track_mlx(self, model: _MlxModel, i: int) -> bool:
        """Transcribe one track with mlx-whisper (Apple-silicon GPU).

        mlx_whisper.transcribe is blocking, so segments arrive when the whole
        track is done rather than live. Whisper's silence-spanning segments
        are split at word gaps just like the faster-whisper path.
        """
        import mlx_whisper

        from audio import decode_track_audio

        track = self.tracks[i]
        self.track_started.emit(i)
        if track.is_subtrack:
            source = decode_track_audio(track.path, track.stream_index, track.channel)
        else:
            source = str(track.path)
        result = mlx_whisper.transcribe(
            source,
            path_or_hf_repo=model.repo,
            language=self.language,
            word_timestamps=True,
            condition_on_previous_text=False,
            initial_prompt=self.hotwords or None,
            verbose=None,
        )
        if self._stop:
            return True
        for seg in result.get("segments", []):
            # mlx-whisper has no VAD filter; drop likely-hallucinated silence.
            if seg.get("no_speech_prob", 0.0) > 0.6:
                continue
            words = seg.get("words") or []
            if not words:
                self.segment_ready.emit(
                    i, Segment(track.speaker, seg["start"], seg["end"], seg["text"]))
                continue
            current = [words[0]]
            for word in words[1:]:
                if word["start"] - current[-1]["end"] > SPLIT_GAP_SECONDS:
                    self.segment_ready.emit(i, Segment(
                        track.speaker, current[0]["start"], current[-1]["end"],
                        "".join(w["word"] for w in current)))
                    current = [word]
                else:
                    current.append(word)
            self.segment_ready.emit(i, Segment(
                track.speaker, current[0]["start"], current[-1]["end"],
                "".join(w["word"] for w in current)))
        self.track_progress.emit(i, 100)
        self.track_done.emit(i, result.get("language") or "")
        return False

    def _transcribe_track_onnx(self, model, i: int) -> bool:
        """Transcribe one track with an onnx-asr model (Parakeet etc.)."""
        from audio import decode_track_audio

        track = self.tracks[i]
        self.track_started.emit(i)
        audio = decode_track_audio(track.path, track.stream_index, track.channel)
        duration = len(audio) / 16000
        for res in model.recognize(audio, sample_rate=16000):
            if self._stop:
                return True
            if not res.text.strip():
                continue
            self.segment_ready.emit(i, Segment(track.speaker, res.start, res.end, res.text))
            if duration > 0:
                self.track_progress.emit(i, min(100, int(res.end / duration * 100)))
        self.track_progress.emit(i, 100)
        self.track_done.emit(i, "")
        return False

    def run(self) -> None:
        try:
            model = self._load_model()
        except Exception as exc:  # model download/load failure on every device tried
            for i in self.indices:
                self.track_failed.emit(i, f"Model load failed: {exc}")
            self.finished_all.emit(False)
            return

        cancelled = False
        for i in self.indices:
            if self._stop:
                cancelled = True
                break
            try:
                cancelled = self._transcribe_track(model, i)
            except Exception as exc:
                if self.device != "cpu":
                    # GPU trouble (e.g. out of VRAM) — spill this and later tracks to CPU.
                    self.model_status.emit(
                        f"GPU error on {self.tracks[i].path.name} ({exc}) — retrying on CPU…"
                    )
                    self.device = "cpu"
                    try:
                        model = _get_model(self.model_name, self.device, self.model_status.emit)
                        cancelled = self._transcribe_track(model, i)
                    except Exception as exc2:
                        self.track_failed.emit(i, str(exc2))
                else:
                    self.track_failed.emit(i, str(exc))

        self.finished_all.emit(cancelled)
