# TransViber TransScriber — Mac edition

Multi-track speaker-aligned transcription, running fully on your Mac.
Built for Apple Silicon (M1 Pro and newer).

## Install (one time)

1. Copy this whole folder somewhere permanent (e.g. Applications or your
   home folder) — not straight from the zip preview.
2. Open **Terminal**, type `bash ` (with the trailing space), drag
   `setup_mac.command` from Finder into the Terminal window, press Enter.
3. Wait for "Setup complete" (downloads a few hundred MB of libraries once).
   If it says no Python 3.10+ was found, install one with
   [Homebrew](https://brew.sh): `brew install python@3.12`, then re-run.

## Run

Double-click **`TransViber TransScriber.command`**.
First launch: macOS may block it — right-click → Open → Open.

## Usage

Identical to the Windows version: drop one audio file per speaker (or a
single multitrack/multichannel file), name the speakers, pick a model,
Transcribe, Export. Vocabulary hints work with Whisper models for D&D names.

## Models & speed on the M1 Pro

- **Device: GPU (Metal/CoreML)** is the default.
  - Whisper models run through **mlx-whisper** on the Metal GPU —
    `large-v3-turbo` is roughly 5–10× faster than real time.
  - `parakeet-tdt-0.6b-v2/v3` run through **CoreML/CPU** — very fast, great
    English accuracy, no vocabulary-hint support.
- **Device: CPU** uses faster-whisper (int8). Fine for smaller models.
- Live segment-by-segment transcript updates only happen on the CPU engine;
  on the Metal GPU each track's text appears when that track finishes.
- Models download on first use to `~/.cache/huggingface` and are then local
  and offline. Everything is free and unlimited.

## Notes

- All processing is local; nothing is uploaded anywhere.
- A 3–4 hour D&D session across 4–5 speaker tracks is a normal workload —
  expect roughly 20–40 minutes with `large-v3-turbo` on the M1 Pro, less
  with Parakeet. Plug the MacBook in; it will run the fans.
