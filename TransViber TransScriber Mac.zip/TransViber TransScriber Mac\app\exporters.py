"""Export merged transcripts to Markdown, plain text, SRT, VTT, and JSON."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from merger import coalesce
from models import Segment, Track


def _hms(seconds: float) -> str:
    s = int(seconds)
    h, rem = divmod(s, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _ts_srt(seconds: float) -> str:
    ms = round(seconds * 1000)
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _ts_vtt(seconds: float) -> str:
    return _ts_srt(seconds).replace(",", ".")


def to_markdown(segments: list[Segment]) -> str:
    lines = ["# Transcript", ""]
    for seg in coalesce(segments):
        lines.append(f"**{seg.speaker}** \\[{_hms(seg.start)}\\]: {seg.text}")
        lines.append("")
    return "\n".join(lines)


def to_text(segments: list[Segment]) -> str:
    lines = []
    for seg in coalesce(segments):
        lines.append(f"[{_hms(seg.start)}] {seg.speaker}: {seg.text}")
        lines.append("")
    return "\n".join(lines)


def to_srt(segments: list[Segment]) -> str:
    lines = []
    for i, seg in enumerate(segments, 1):
        lines.append(str(i))
        lines.append(f"{_ts_srt(seg.start)} --> {_ts_srt(seg.end)}")
        lines.append(f"{seg.speaker}: {seg.text.strip()}")
        lines.append("")
    return "\n".join(lines)


def to_vtt(segments: list[Segment]) -> str:
    lines = ["WEBVTT", ""]
    for seg in segments:
        lines.append(f"{_ts_vtt(seg.start)} --> {_ts_vtt(seg.end)}")
        lines.append(f"<v {seg.speaker}>{seg.text.strip()}")
        lines.append("")
    return "\n".join(lines)


def to_json(segments: list[Segment], tracks: list[Track], model_name: str) -> str:
    data = {
        "created": datetime.now().astimezone().isoformat(timespec="seconds"),
        "model": model_name,
        "tracks": [
            {
                "file": str(t.path),
                "speaker": t.speaker,
                "duration": round(t.duration, 3),
                "language": t.language,
                "stream": t.stream_index,
                "channel": t.channel,
            }
            for t in tracks
        ],
        "segments": [
            {
                "speaker": seg.speaker,
                "start": round(seg.start, 3),
                "end": round(seg.end, 3),
                "text": seg.text.strip(),
            }
            for seg in segments
        ],
    }
    return json.dumps(data, ensure_ascii=False, indent=2)


EXPORTERS = {
    ".md": to_markdown,
    ".txt": to_text,
    ".srt": to_srt,
    ".vtt": to_vtt,
    ".json": to_json,
}


def export(path: Path, segments: list[Segment], tracks: list[Track], model_name: str) -> None:
    ext = path.suffix.lower()
    if ext == ".json":
        content = to_json(segments, tracks, model_name)
    elif ext in EXPORTERS:
        content = EXPORTERS[ext](segments)
    else:
        raise ValueError(f"Unsupported export format: {ext}")
    path.write_text(content, encoding="utf-8")


def export_all(base_path: Path, segments: list[Segment], tracks: list[Track], model_name: str) -> list[Path]:
    written = []
    for ext in EXPORTERS:
        target = base_path.with_suffix(ext)
        export(target, segments, tracks, model_name)
        written.append(target)
    return written
