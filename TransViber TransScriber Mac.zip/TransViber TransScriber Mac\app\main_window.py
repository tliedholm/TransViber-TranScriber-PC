"""Main application window."""

from __future__ import annotations

import html
import sys
from pathlib import Path

from PySide6.QtCore import QSettings, Qt, QTimer, Slot
from PySide6.QtGui import QDragEnterEvent, QDropEvent
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

import exporters
from audio import _channel_suffixes, probe_streams, tracks_for_file
from merger import coalesce, merge_tracks
from models import AUDIO_EXTENSIONS, Track, TrackStatus
from transcriber import TranscribeWorker, cuda_available, engine_for, mlx_available

IS_MAC = sys.platform == "darwin"

MODELS = [
    "large-v3-turbo", "large-v3", "large-v2", "distil-large-v3",
    "parakeet-tdt-0.6b-v3", "parakeet-tdt-0.6b-v2", "canary-1b-v2",
    "medium", "medium.en", "small", "small.en",
    "base", "base.en", "tiny", "tiny.en",
]

LANGUAGES = [
    ("Auto-detect", None), ("English", "en"), ("Swedish", "sv"), ("Spanish", "es"),
    ("French", "fr"), ("German", "de"), ("Italian", "it"), ("Portuguese", "pt"),
    ("Dutch", "nl"), ("Danish", "da"), ("Norwegian", "no"), ("Finnish", "fi"),
    ("Polish", "pl"), ("Russian", "ru"), ("Ukrainian", "uk"), ("Japanese", "ja"),
    ("Korean", "ko"), ("Chinese", "zh"), ("Arabic", "ar"), ("Hindi", "hi"),
    ("Turkish", "tr"),
]

COL_SPEAKER, COL_FILE, COL_DURATION, COL_STATUS, COL_PROGRESS = range(5)

FILE_FILTER = "Audio files (*" + " *".join(sorted(AUDIO_EXTENSIONS)) + ");;All files (*.*)"

EXPORT_FILTERS = (
    "Markdown (*.md);;Plain text (*.txt);;SubRip subtitles (*.srt);;"
    "WebVTT subtitles (*.vtt);;JSON (*.json);;All formats (*.md *.txt *.srt *.vtt *.json)"
)


def _fmt_duration(seconds: float) -> str:
    s = int(seconds)
    h, rem = divmod(s, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TransViber TransScriber")
        self.resize(1100, 750)
        self.setAcceptDrops(True)

        self.tracks: list[Track] = []
        self.worker: TranscribeWorker | None = None
        self.has_cuda = not IS_MAC and cuda_available()
        self.has_mlx = mlx_available()

        self._build_ui()
        self._load_settings()
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(400)
        self._refresh_timer.setSingleShot(True)
        self._refresh_timer.timeout.connect(self._render_transcript)

    # ---------- UI construction ----------

    def _build_ui(self) -> None:
        central = QWidget()
        root = QVBoxLayout(central)

        # Top control bar
        bar = QHBoxLayout()
        self.btn_add = QPushButton("Add Files…")
        self.btn_add.clicked.connect(self.add_files_dialog)
        self.btn_remove = QPushButton("Remove")
        self.btn_remove.clicked.connect(self.remove_selected)
        self.btn_clear = QPushButton("Clear")
        self.btn_clear.clicked.connect(self.clear_tracks)
        bar.addWidget(self.btn_add)
        bar.addWidget(self.btn_remove)
        bar.addWidget(self.btn_clear)
        bar.addSpacing(20)

        bar.addWidget(QLabel("Model:"))
        self.combo_model = QComboBox()
        self.combo_model.addItems(MODELS)
        self.combo_model.setEditable(True)
        self.combo_model.setToolTip(
            "Whisper models: pick a size, or type any CTranslate2 repo from\n"
            "Hugging Face (e.g. distil-whisper/distil-large-v3.5-ct2).\n"
            "'.en' models are English-only and slightly more accurate for English.\n"
            "\n"
            "NVIDIA models (via onnx-asr): parakeet-tdt-0.6b-v2 (English) and\n"
            "-v3 (25 European languages) — faster than Whisper, top English\n"
            "accuracy. canary-1b-v2 — most accurate, but licensed for\n"
            "non-commercial use only. The Language setting is ignored (auto)."
        )
        bar.addWidget(self.combo_model)

        bar.addWidget(QLabel("Language:"))
        self.combo_lang = QComboBox()
        for name, code in LANGUAGES:
            self.combo_lang.addItem(name, code)
        bar.addWidget(self.combo_lang)

        bar.addWidget(QLabel("Device:"))
        self.combo_device = QComboBox()
        if IS_MAC:
            self.combo_device.addItem("GPU (Metal/CoreML)", "mlx")
            self.combo_device.addItem("CPU", "cpu")
            if not self.has_mlx:
                self.combo_device.setToolTip(
                    "Whisper models need mlx-whisper for the GPU (run setup_mac.sh);\n"
                    "without it they run on CPU. Parakeet/Canary use CoreML either way."
                )
        else:
            self.combo_device.addItem(
                "GPU (CUDA)" if self.has_cuda else "GPU (unavailable)", "cuda")
            self.combo_device.addItem("CPU", "cpu")
            if not self.has_cuda:
                self.combo_device.model().item(0).setEnabled(False)
                self.combo_device.setCurrentIndex(1)
        bar.addWidget(self.combo_device)

        bar.addStretch()
        self.btn_transcribe = QPushButton("Transcribe")
        self.btn_transcribe.setDefault(True)
        self.btn_transcribe.clicked.connect(self.toggle_transcription)
        bar.addWidget(self.btn_transcribe)
        self.btn_export = QPushButton("Export…")
        self.btn_export.clicked.connect(self.export_dialog)
        self.btn_export.setEnabled(False)
        bar.addWidget(self.btn_export)
        root.addLayout(bar)

        # Vocabulary hints (Whisper only): bias recognition toward unusual
        # names and terms — campaign characters, places, jargon. Hidden when
        # a non-Whisper model (Parakeet/Canary) is selected.
        self.hints_widget = QWidget()
        hints_bar = QHBoxLayout(self.hints_widget)
        hints_bar.setContentsMargins(0, 0, 0, 0)
        hints_bar.addWidget(QLabel("Vocabulary hints:"))
        self.edit_hints = QLineEdit()
        self.edit_hints.setPlaceholderText(
            "Names and terms to spell correctly, e.g. Zephyrine, Thaldrin, "
            "Waterdeep, vecna, owlbear"
        )
        self.edit_hints.setToolTip(
            "Comma-separated words or phrases the audio is likely to contain.\n"
            "Whisper is nudged toward these spellings — great for D&D character\n"
            "names, places, and other words it would otherwise mangle.\n"
            "Remembered between sessions."
        )
        hints_bar.addWidget(self.edit_hints)
        root.addWidget(self.hints_widget)
        self.combo_model.currentTextChanged.connect(self._update_hints_visibility)

        # Track table + transcript view
        splitter = QSplitter(Qt.Orientation.Vertical)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Speaker", "File", "Duration", "Status", "Progress"])
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(COL_SPEAKER, QHeaderView.ResizeMode.Interactive)
        header.setSectionResizeMode(COL_FILE, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(COL_DURATION, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(COL_STATUS, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(COL_PROGRESS, QHeaderView.ResizeMode.Fixed)
        self.table.setColumnWidth(COL_SPEAKER, 180)
        self.table.setColumnWidth(COL_PROGRESS, 140)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.itemChanged.connect(self._on_item_changed)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._show_table_menu)
        splitter.addWidget(self.table)

        self.transcript_view = QTextBrowser()
        self.transcript_view.setOpenExternalLinks(False)
        self.transcript_view.setPlaceholderText(
            "Drop audio tracks above (one file per speaker), set speaker names, "
            "then click Transcribe. The merged conversation appears here."
        )
        splitter.addWidget(self.transcript_view)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        root.addWidget(splitter)

        self.setCentralWidget(central)

        if IS_MAC:
            device_text = ("GPU: Apple Silicon (Metal/CoreML)" if self.has_mlx
                           else "GPU: CoreML (mlx-whisper not installed)")
        elif self.has_cuda:
            device_text = "GPU: CUDA available"
        else:
            device_text = "GPU not available — using CPU"
        self.device_label = QLabel(device_text)
        self.statusBar().addPermanentWidget(self.device_label)
        self.statusBar().showMessage("Ready")

    def _update_hints_visibility(self) -> None:
        model = self.combo_model.currentText().strip()
        self.hints_widget.setVisible(engine_for(model) == "whisper")

    # ---------- Drag & drop ----------

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if self.worker is None and any(
            Path(u.toLocalFile()).suffix.lower() in AUDIO_EXTENSIONS
            for u in event.mimeData().urls()
        ):
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent) -> None:
        paths = [
            Path(u.toLocalFile())
            for u in event.mimeData().urls()
            if Path(u.toLocalFile()).suffix.lower() in AUDIO_EXTENSIONS
        ]
        self.add_files(paths)

    # ---------- Track management ----------

    def add_files_dialog(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(self, "Add audio tracks", "", FILE_FILTER)
        self.add_files([Path(f) for f in files])

    def add_files(self, paths: list[Path]) -> None:
        existing = {t.path for t in self.tracks}
        for path in paths:
            if path in existing or not path.is_file():
                continue
            for track in tracks_for_file(path):
                self.tracks.append(track)
                self._append_row(track)
            existing.add(path)
        self.statusBar().showMessage(f"{len(self.tracks)} track(s) loaded")

    def _append_row(self, track: Track, row: int | None = None) -> None:
        if row is None:
            row = self.table.rowCount()
        self.table.blockSignals(True)
        self.table.insertRow(row)

        speaker_item = QTableWidgetItem(track.speaker)
        self.table.setItem(row, COL_SPEAKER, speaker_item)

        for col, text in [
            (COL_FILE, track.source_label),
            (COL_DURATION, _fmt_duration(track.duration)),
            (COL_STATUS, track.status.value),
        ]:
            item = QTableWidgetItem(text)
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            if col == COL_FILE:
                item.setToolTip(str(track.path))
            self.table.setItem(row, col, item)

        progress = QProgressBar()
        progress.setRange(0, 100)
        progress.setValue(0)
        self.table.setCellWidget(row, COL_PROGRESS, progress)
        self.table.blockSignals(False)

    def _on_item_changed(self, item: QTableWidgetItem) -> None:
        if item.column() != COL_SPEAKER:
            return
        row = item.row()
        if 0 <= row < len(self.tracks):
            track = self.tracks[row]
            new_name = item.text().strip() or track.speaker
            track.speaker = new_name
            for seg in track.segments:
                seg.speaker = new_name
            self._schedule_refresh()

    def _show_table_menu(self, pos) -> None:
        row = self.table.rowAt(pos.y())
        if row < 0 or self.worker is not None:
            return
        track = self.tracks[row]
        menu = QMenu(self)
        split = menu.addAction("Split into one speaker per channel")
        split.setEnabled(track.channel is None)
        if menu.exec(self.table.viewport().mapToGlobal(pos)) is split:
            self._split_track_channels(row)

    def _split_track_channels(self, row: int) -> None:
        track = self.tracks[row]
        try:
            streams = probe_streams(track.path)
            channels = streams[track.stream_index or 0]["channels"]
        except Exception as exc:
            QMessageBox.warning(self, "Cannot split", str(exc))
            return
        if channels < 2:
            QMessageBox.information(self, "Mono track",
                                    "This track has only one channel — nothing to split.")
            return
        self.table.removeRow(row)
        del self.tracks[row]
        for ch, suffix in enumerate(_channel_suffixes(channels)):
            new = Track(path=track.path, speaker=track.speaker + suffix,
                        duration=track.duration, stream_index=track.stream_index,
                        channel=ch)
            self.tracks.insert(row + ch, new)
            self._append_row(new, row + ch)
        self._schedule_refresh()

    def remove_selected(self) -> None:
        if self.worker is not None:
            return
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        for row in rows:
            self.table.removeRow(row)
            del self.tracks[row]
        self._schedule_refresh()

    def clear_tracks(self) -> None:
        if self.worker is not None:
            return
        self.table.setRowCount(0)
        self.tracks.clear()
        self.transcript_view.clear()
        self.btn_export.setEnabled(False)

    # ---------- Transcription ----------

    def toggle_transcription(self) -> None:
        if self.worker is not None:
            self.btn_transcribe.setEnabled(False)
            self.btn_transcribe.setText("Cancelling…")
            self.worker.stop()
            return

        indices = [i for i, t in enumerate(self.tracks) if t.status != TrackStatus.DONE]
        if not indices:
            indices = list(range(len(self.tracks)))  # everything done -> re-run all
        if not indices:
            QMessageBox.information(self, "No tracks", "Add at least one audio track first.")
            return

        for i in indices:
            track = self.tracks[i]
            track.segments.clear()
            track.status = TrackStatus.PENDING
            track.error = ""
            self._set_status(i, track.status.value)
            self._progress_bar(i).setValue(0)

        device = self.combo_device.currentData()
        self.worker = TranscribeWorker(
            self.tracks, indices,
            model_name=self.combo_model.currentText().strip(),
            device=device,
            language=self.combo_lang.currentData(),
            hotwords=self.edit_hints.text(),
        )
        w = self.worker
        w.model_status.connect(self.statusBar().showMessage)
        w.track_started.connect(self._on_track_started)
        w.segment_ready.connect(self._on_segment)
        w.track_progress.connect(lambda i, p: self._progress_bar(i).setValue(p))
        w.track_done.connect(self._on_track_done)
        w.track_failed.connect(self._on_track_failed)
        w.finished_all.connect(self._on_finished)
        self._set_running(True)
        w.start()

    def _set_running(self, running: bool) -> None:
        for widget in (self.btn_add, self.btn_remove, self.btn_clear,
                       self.combo_model, self.combo_lang, self.combo_device,
                       self.edit_hints):
            widget.setEnabled(not running)
        self.btn_export.setEnabled(not running and bool(merge_tracks(self.tracks)))
        self.btn_transcribe.setText("Cancel" if running else "Transcribe")
        self.btn_transcribe.setEnabled(True)
        if not running and self.has_cuda:
            pass  # device combo re-enabled above; GPU entry stays valid

    def _progress_bar(self, row: int) -> QProgressBar:
        return self.table.cellWidget(row, COL_PROGRESS)

    def _set_status(self, row: int, text: str) -> None:
        self.table.blockSignals(True)
        self.table.item(row, COL_STATUS).setText(text)
        self.table.blockSignals(False)

    @Slot(int)
    def _on_track_started(self, i: int) -> None:
        track = self.tracks[i]
        track.segments.clear()  # a CPU-fallback retry restarts the track from scratch
        track.status = TrackStatus.TRANSCRIBING
        self._set_status(i, TrackStatus.TRANSCRIBING.value)
        self._progress_bar(i).setValue(0)
        self.statusBar().showMessage(f"Transcribing {track.path.name}…")
        self._schedule_refresh()

    @Slot(int, object)
    def _on_segment(self, i: int, segment) -> None:
        self.tracks[i].segments.append(segment)
        self._schedule_refresh()

    @Slot(int, str)
    def _on_track_done(self, i: int, language: str) -> None:
        track = self.tracks[i]
        track.status = TrackStatus.DONE
        track.language = language
        label = TrackStatus.DONE.value + (f" ({language})" if language else "")
        self._set_status(i, label)

    @Slot(int, str)
    def _on_track_failed(self, i: int, message: str) -> None:
        track = self.tracks[i]
        track.status = TrackStatus.ERROR
        track.error = message
        self._set_status(i, TrackStatus.ERROR.value)
        self.table.item(i, COL_STATUS).setToolTip(message)

    @Slot(bool)
    def _on_finished(self, cancelled: bool) -> None:
        if self.worker is not None:
            self.worker.wait()
            self.worker = None
        if cancelled:
            for i, track in enumerate(self.tracks):
                if track.status == TrackStatus.TRANSCRIBING:
                    track.status = TrackStatus.CANCELLED
                    self._set_status(i, TrackStatus.CANCELLED.value)
        errors = [t for t in self.tracks if t.status == TrackStatus.ERROR]
        if cancelled:
            msg = "Cancelled"
        elif errors:
            msg = f"Finished with {len(errors)} error(s)"
        else:
            msg = "Transcription complete"
        self.statusBar().showMessage(msg)
        self._set_running(False)
        self._render_transcript()
        if errors and not cancelled:
            detail = "\n\n".join(f"{t.source_label}:\n{t.error}" for t in errors[:5])
            QMessageBox.warning(self, "Some tracks failed", detail)

    # ---------- Transcript view ----------

    def _schedule_refresh(self) -> None:
        if not self._refresh_timer.isActive():
            self._refresh_timer.start()

    def _render_transcript(self) -> None:
        segments = merge_tracks(self.tracks)
        if not segments:
            self.transcript_view.clear()
            return
        parts = []
        for seg in coalesce(segments):
            ts = _fmt_duration(seg.start)
            parts.append(
                f"<p><b>{html.escape(seg.speaker)}</b> "
                f"<span style='color:gray'>[{ts}]</span>: "
                f"{html.escape(seg.text.strip())}</p>"
            )
        scrollbar = self.transcript_view.verticalScrollBar()
        at_bottom = scrollbar.value() >= scrollbar.maximum() - 10
        self.transcript_view.setHtml("\n".join(parts))
        if at_bottom:
            scrollbar.setValue(scrollbar.maximum())

    # ---------- Export ----------

    def export_dialog(self) -> None:
        segments = merge_tracks(self.tracks)
        if not segments:
            return
        default_name = str(Path.home() / "transcript.md")
        path_str, selected = QFileDialog.getSaveFileName(
            self, "Export transcript", default_name, EXPORT_FILTERS
        )
        if not path_str:
            return
        path = Path(path_str)
        model_name = self.combo_model.currentText()
        try:
            if selected.startswith("All formats"):
                written = exporters.export_all(path, segments, self.tracks, model_name)
                self.statusBar().showMessage("Exported: " + ", ".join(p.name for p in written))
            else:
                if path.suffix.lower() not in exporters.EXPORTERS:
                    ext = selected.split("*")[1].rstrip(") ")
                    path = path.with_suffix(ext)
                exporters.export(path, segments, self.tracks, model_name)
                self.statusBar().showMessage(f"Exported {path}")
        except OSError as exc:
            QMessageBox.critical(self, "Export failed", str(exc))

    # ---------- Settings persistence ----------

    def _load_settings(self) -> None:
        settings = QSettings()
        self.edit_hints.setText(settings.value("hints", "", str))
        model = settings.value("model", "", str)
        if model:
            self.combo_model.setCurrentText(model)
        lang_index = self.combo_lang.findData(settings.value("language", None))
        if lang_index >= 0:
            self.combo_lang.setCurrentIndex(lang_index)
        self._update_hints_visibility()

    def _save_settings(self) -> None:
        settings = QSettings()
        settings.setValue("hints", self.edit_hints.text())
        settings.setValue("model", self.combo_model.currentText().strip())
        settings.setValue("language", self.combo_lang.currentData())

    # ---------- Shutdown ----------

    def closeEvent(self, event) -> None:
        self._save_settings()
        if self.worker is not None:
            self.worker.stop()
            self.worker.wait(5000)
        event.accept()
