# TransViber TransScriber — Mac edition

PySide6 desktop app that transcribes multi-track recordings (one audio
file/stream/channel per speaker) locally and merges the segments into one
conversation ordered by who speaks when. This is the macOS fork of a Windows
app; the user's PC copy is maintained separately — changes here do NOT need
to stay compatible with Windows, but the user may ask to port fixes across.

## Run / setup

- One-time: `bash setup_mac.command` (creates `.venv`, installs deps incl.
  mlx-whisper). Launch: `./TransViber TransScriber.command` or
  `.venv/bin/python app/main.py`.
- Models download to `~/.cache/huggingface` on first use.

## Architecture (app/)

- `main.py` — entry point.
- `main_window.py` — all UI. Track table + live merged transcript.
  `IS_MAC` switches the Device combo to "GPU (Metal/CoreML)" (`"mlx"`) / CPU.
  Settings (model, language, vocab hints) persist via QSettings.
- `transcriber.py` — `TranscribeWorker` (QThread) with three engine paths,
  dispatched per model name / device:
  1. faster-whisper (CTranslate2, CPU on Mac) — Whisper names like
     `large-v3-turbo`.
  2. mlx-whisper (`_MlxModel`, Apple GPU) — used when device is `"mlx"` and
     mlx_whisper imports; `MLX_REPOS` maps Whisper names to mlx-community
     HF repos.
  3. onnx-asr (`engine_for()` routes parakeet/canary/nemo-*) — NVIDIA
     Parakeet/Canary with silero VAD; CoreML EP when device is `"mlx"`.
  Any GPU failure falls back to CPU automatically and retries the track.
- `audio.py` — `tracks_for_file()` expands multitrack files (multiple audio
  streams -> track per stream; >2 channels -> track per channel; stereo split
  is a right-click action). `decode_track_audio()` -> mono float32 16 kHz.
- `merger.py` / `exporters.py` — chronological merge, same-speaker
  coalescing, and md/txt/srt/vtt/json exporters.

## Critical invariants — do not break

- **Word-gap splitting**: Whisper merges utterances separated by silence
  into one segment, which destroys the chronological interleaving. Both
  Whisper paths must split segments at word gaps > `SPLIT_GAP_SECONDS` (1 s)
  using word timestamps (`split_on_word_gaps` for faster-whisper; inline
  dict-based splitting in `_transcribe_track_mlx`).
- **Hallucination guards**: faster-whisper uses `vad_filter=True`; the MLX
  path has no VAD so it drops segments with `no_speech_prob > 0.6`. Sparse
  speaker tracks are mostly silence — removing these guards produces
  garbage text at silent stretches.
- All tracks are assumed to start at the same instant (multitrack recorder
  convention); merging is a sort by segment start time.
- Vocabulary hints: faster-whisper uses `hotwords=`, MLX uses
  `initial_prompt=`; the field is hidden for onnx models (no support).
- The MLX path is the only part never tested on real hardware before the
  user's M1 Pro — if something breaks first, look there (repo names in
  `MLX_REPOS`, mlx_whisper.transcribe kwargs, word dict shapes).

## User context

- Primary use: transcribing D&D sessions (Discord/Craig multitrack
  recordings); vocab hints hold campaign names.
- Everything must stay free/local/unlimited — no cloud transcription APIs.
